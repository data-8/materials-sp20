test = {
  'name': 'q1_20',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> -0.75 <= one_simulated_test_stat <= 0.75
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
