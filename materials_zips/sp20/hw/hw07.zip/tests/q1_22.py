test = {
  'name': 'q1_22',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> p_value_ab > 0.05
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
