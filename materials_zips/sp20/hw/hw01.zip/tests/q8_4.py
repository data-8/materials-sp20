test = {
  'name': 'q8_4',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> gradescope == 82441
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
