test = {
  'name': 'Question 8_2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> grades == 2
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
