test = {
  'name': 'q7_1_1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> all([type(num_people_more_than_10_miles_away_alameda_county) != type(...), 
          ...      type(num_people_more_than_10_miles_away_alameda_county) != None])
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
