test = {
  'name': 'q3_1_1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> cancer
          cancer status | negative | positive
          healthy       | 9702     | 198
          sick          | 10       | 90
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
