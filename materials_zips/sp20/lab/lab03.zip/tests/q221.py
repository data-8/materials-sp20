test = {
  'name': 'q221',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> population_1973
          3942096442
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
