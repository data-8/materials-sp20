test = {
  'name': 'q111',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> new_word
          'matchmaker'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
